export const getTweets = (query) => ({
      type: 'GET_TWEETS',
      payload: {
      	query
      }
});