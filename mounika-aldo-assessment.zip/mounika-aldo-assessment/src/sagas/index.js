import { put, takeLatest, all } from 'redux-saga/effects';

function* fetchTweets({ payload }) {
  const tweets = yield fetch('http://localhost:8080/tweets?q='+payload.query, { 
		headers: new Headers({
		 	'consumer-key': 'ws281yxtP3LSA3oviNtgVj9eW', 
		 	'consumer-secret': 'DmKvrfaKHm6RMzuXClZuT3XbRIsUwcr9UDCc6HVxfXlfHBKaN4',
		 	'access-token-key': '1279447913891012609-gq4YgPbf1czcRhGIUp4wdWO0g4u69M',
		 	'access-token-secret': 'LnukMDWC0n2Ede9QY1XO3ZmnPBfGUPWSrTomZYEA5AgfP'
		})
 	}).then(response => response.json());
	yield put({ type: "TWEETS_RECEIVED", tweets: tweets });
}

function* actionWatcher() {
     yield takeLatest('GET_TWEETS', fetchTweets)
}

export default function* rootSaga() {
	yield all([
		actionWatcher(),
	]);
}