const reducer = (state = {loading: true, tweets: []}, action) => {
  switch (action.type) {
			case 'GET_TWEETS':
        return { ...state, loading: true};
    	case 'TWEETS_RECEIVED':
        return { ...state, loading: false, tweets: action.tweets }
     	default:
        return state;
   }
};

export default reducer;