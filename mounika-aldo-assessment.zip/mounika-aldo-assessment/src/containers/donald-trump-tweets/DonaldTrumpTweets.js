import React from 'react';
import { connect } from 'react-redux';
import { getTweets } from './../../actions';
import Tweets from './../../components/tweets/Tweets';

let DonaldTrumpTweets=({ loading, tweets, getTweets })=> {
	const query = 'Donald Trump';
	if(loading) {
		getTweets(query);
	}
	return (
		<Tweets query={query} loading={loading} tweets={tweets} />
	);
};

const mapStateToProps = (state) => ({
	loading: state.loading,
	tweets: state.tweets,
})

const mapDispatchToProps = {
     getTweets: getTweets,
};

DonaldTrumpTweets = connect(mapStateToProps, mapDispatchToProps)(DonaldTrumpTweets);

export default DonaldTrumpTweets;