import React from 'react';
import { BrowserRouter as Router, Switch, Route, Redirect } from "react-router-dom";
import Header from './components/common/header/Header';
import DonaldTrumpTweets from './containers/donald-trump-tweets/DonaldTrumpTweets';
import HillaryClintonTweets from './containers/hillary-clinton-tweets/HillaryClintonTweets';
import './app.scss';

class App extends React.Component {
  render() {
    return (
      <div className='app'>
        <Header />
        <div className='main-body container-fluid'>
        	<Router>
        		<Switch>
		          <Route exact path='/'>
		            <DonaldTrumpTweets />
                <Redirect to='/donald-trump-tweets' />
		          </Route>
		          <Route path='/donald-trump-tweets'>
		            <DonaldTrumpTweets />
		          </Route>
		          <Route path='/hillary-clinton-tweets'>
		            <HillaryClintonTweets />
		          </Route>
		        </Switch>
        	</Router>
        </div>
      </div>
    );
  }
}

export default App;
