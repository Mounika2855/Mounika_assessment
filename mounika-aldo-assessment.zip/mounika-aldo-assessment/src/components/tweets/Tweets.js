import React from 'react';
import { Spinner, ListGroup } from 'react-bootstrap';
import './tweets.scss';

export default function Tweets({ query, loading, tweets }) {
  return (
    <div className='tweets'>
    	<div className='row'>
    		<div className='col-md-4 offset-md-4'>
    			<div className='title'>Showing tweets for <b><i>{ query }</i></b></div>
    			{
    				loading && 
    				(<div className='spinner'>
    					<Spinner animation="border" role="status">
							  <span className="sr-only">Loading...</span>
							</Spinner>
    				</div>)
    			}
    			{
    				!loading && 
    				(<ListGroup>
    					{
    						tweets.map((t, index) => <ListGroup.Item key={index} className='tweet'>
    							{t.text}
    							<div className='details'>
    								<img className='profile-pic' src={t.profile_image} />
  									<span className='user-name'>{t.posted_by}</span>
  									<span className='posted-at'>{new Date(t.posted_at).toGMTString()}</span>
    							</div>
    						</ListGroup.Item>)
    					}
    				</ListGroup>)
    			}
    		</div>
    	</div>
    </div>
  );
}