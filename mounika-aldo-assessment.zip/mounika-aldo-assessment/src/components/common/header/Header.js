import React from 'react';
import { Navbar, Nav } from 'react-bootstrap';
import logo from './../../../logo.svg';

export default function Header() {
  const path = window.location.pathname;
  return (
    <Navbar bg='dark' variant='dark'>
      <Navbar.Brand href='/donald-trump-tweets'>
        <img
          alt=''
          src={logo}
          width='30'
          height='30'
          className='d-inline-block align-top'
        />{' '}
        ALDO Group Assessment
      </Navbar.Brand>
      <Nav className='mr-auto'>
        <Nav.Link href='/donald-trump-tweets' className={path==='/donald-trump-tweets' ? 'active' : ''}>Donald Trump Tweets</Nav.Link>
        <Nav.Link href='/hillary-clinton-tweets' className={path==='/hillary-clinton-tweets' ? 'active' : ''}>Hillary Clinton Tweets</Nav.Link>
      </Nav>
    </Navbar>
  );
}