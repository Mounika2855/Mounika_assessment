const express = require('express');
var cors = require('cors');
const Twitter = require('twitter-lite');

const app = express();
app.use(cors());

const port = 8080;

app.get('/tweets', async (req, res) => {
	const app = new Twitter({
		subdomain: "api",
		version: "1.1",
	  consumer_key: req.get('consumer-key'),
	  consumer_secret: req.get('consumer-secret'),
	  access_token_key: req.get('access-token-key'),
  	access_token_secret: req.get('access-token-secret')
	});
	const parameters = {
		q: req.query.q,
		count: 99
	}
	const tweets = await app.get("search/tweets", parameters);
	res.send(tweets.statuses.	map(t => {
		return {
			'posted_at': t.created_at,
			'text': t.text,
			'posted_by': t.user.name,
			'profile_image': t.user.profile_image_url_https
		}
	}));	
});

app.listen(port, () => console.log(`tweeter api app listening on port ${port}!`))